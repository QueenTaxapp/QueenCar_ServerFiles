<?php
namespace App\Containers\Drivers\Webtasks;

use App\Containers\Admin\Tasks\Message;
use App\Ship\Parents\Tasks\Task;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\DB;
use App\Containers\Admin\Models\AdminModel;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use App\Ship\Exceptions\CommonException;

class DriverDetailsMapTask extends Task
{

    public function run()
    {

        $tableNameSpace ='App\Containers\Drivers\Models\DriverModel';
        $array = array('Drivers.id','Drivers.firstname','is_available','Driver_Details.latitude','Driver_Details.longitude');

        $result = $tableNameSpace::join('Driver_Details', 'Driver_Details.driver_id', '=', 'Drivers.id')
                         ->select($array) 
                         ->where('Drivers.is_active','1')
                         ->where('Drivers.is_approve','1') 
                         ->get();
                               
        return $result;
    }

}


