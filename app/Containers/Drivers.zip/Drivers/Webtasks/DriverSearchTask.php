<?php

namespace App\Containers\Drivers\Webtasks;

use App\Containers\Common\GetConfigs;
use App\Containers\Drivers\Models\DriverModel;
use App\Ship\Parents\Tasks\Task;

/**

 * Class WebLoginTask.
 *
 * @author Mahmoud Zalt <mahmoud@zalt.me>
 */
class DriverSearchTask extends Task
{
    /**
     * Save User Detail
     * @param Object $request
     * @param String $token
     *
     * @return  Object
     */
    public function run($request)
    {
        $page = GetConfigs::getConfigs('paginate');
        $value = $request->filter_value;
        $type = $request->filter_type;
        $request->session()->put('filter_value', $value);
        $request->session()->put('filter_type', $type);

        $query=DriverModel::select('*');


        if ($type == 'registration_code')
        {

            if ($request->submit && $request->submit == 'Download_Report')
            {

                $drivers = $query->where('registration_code', 'like', $value . '%')->get();

            }
            else
            {

                $drivers = $query->where('registration_code', 'like', $value. '%')->paginate($page);

            }
        }
        elseif ($type == 'name')
        {

            if ($request->submit && $request->submit == 'Download_Report')
            {

                $drivers = $query->where('firstname', 'like', '%' . $value . '%')->orWhere('lastname', 'like', '%' . $value . '%')->get();

            }
            else
            {

                $drivers = $query->where('firstname', 'like', '%' . $value . '%')->orWhere('lastname', 'like', '%' . $value . '%')->paginate($page);

            }
        }
        elseif ($type == 'email')
        {

            if ($request->submit && $request->submit == 'Download_Report')
            {

                $drivers = $query->where('email', 'like', '%' . $value . '%')->get();

            }
            else
            {

                $drivers = $query->where('email', 'like', '%' . $value . '%')->paginate($page);

            }
        }
        elseif ($type == 'phone')
        {

            if ($request->submit && $request->submit == 'Download_Report')
            {

                $drivers = $query->where('phone_number', 'like', '%' . $value . '%')->get();

            }
            else
            {

                $drivers = $query->where('phone_number', 'like', '%' . $value . '%')->paginate($page);
            }
        }

        return $drivers;

    }

}
