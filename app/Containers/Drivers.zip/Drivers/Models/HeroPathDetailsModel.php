<?php

namespace App\Containers\Drivers\Models;
use App\Containers\Stripe\Models\StripeAccount;
use App\Ship\Parents\Models\UserModel;



class HeroPathDetailsModel extends UserModel
{
    protected $dates = ['deleted_at'];
    protected  $table = '911_Hero_Path_Details';
}
