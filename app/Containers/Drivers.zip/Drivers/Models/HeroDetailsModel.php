<?php

namespace App\Containers\Drivers\Models;
use App\Containers\Stripe\Models\StripeAccount;
use App\Ship\Parents\Models\UserModel;


class HeroDetailsModel extends UserModel
{
    protected  $table = '911_Hero_Details';

}