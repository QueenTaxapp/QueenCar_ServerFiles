<?php
/**
 * Created by PhpStorm.
 * User: server-team-1
 * Date: 11/3/17
 * Time: 7:28 PM
 */

namespace App\Containers\Drivers\ApiTask;
use App\Containers\User\Models\Fav;
use App\Ship\Exceptions\CommonException;



class DriverProfileUpdateTask
{


    public function run($data, $custom_parameter)
    {

        $tableNameSpace = 'App\Containers\Drivers\Models\DriverModel';

        $request = $data['request'];
        $id = $request->id;



        $driver = $tableNameSpace::select('password','profile_pic')->where('id',$id)->first();


        $imageName = $driver->profile_pic;

        $hashedPassword  = $driver->password;

        $plainText = $request->old_password;


        if($request->has('old_password'))
        {
            passwordCheck($plainText,$hashedPassword,'801');

            $password = $hashedPassword;Hash::make($request->new_password);
        }
        else
        {
            $password = $hashedPassword;
        }



        if( $request->hasFile('profile_pic') )
        {
            $imageName = insertImagePath($request,'profile_pic');
        }

        $update = $tableNameSpace::where('id',$id)
                    ->update(['firstname'=> $request->firstname,'lastname'=> $request->lastname,'password'=> $password,'profile_pic'=> $imageName]);


        if(!$update)
        {
            throw (new CommonException())->setValue('',trans('localization::errors.721'));
        }
        else
        {
            $message = trans('localization::errors.profile_updated_successfully');
            $obj = new \stdClass();
            $obj->message = $message;
            $data['response']=$obj;
            return $data;
        }

    }
}