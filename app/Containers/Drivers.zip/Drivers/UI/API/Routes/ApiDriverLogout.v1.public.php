<?php

/**
 * @apiGroup           Driver
 * @apiName            Driver Logout
 * @api                {post} /driver/forgotpassword Driver Logout
 * @apiDescription     Driver Logout
 * @apiVersion         1.0.0
 * @apiPermission      none
 *
 * @apiParam              {Integer}     id
 * @apiParam              {String}     token
 *
 * @apiHeader          Accept application/json
 *
 *
 *
 * @apiSuccessExample  {json}    Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *   "success": true,
 *   "user": {
 *       "is_presented": true
 *           }
 *   "success_message" : "Logged_out"
 *   }
 *
 */

    $router->post('/driver/logout', [
        'as'   => 'LogoutDriver',
        'uses' => 'Controller@Logout',
    ]);



