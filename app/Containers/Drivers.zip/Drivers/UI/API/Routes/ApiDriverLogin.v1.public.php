<?php

/**
 * @apiGroup           Driver
 * @apiName            DriverLogin
 * @api                {post} /driver/login Driver Login
 * @apiDescription     Driver Login
 * @apiVersion         1.0.0
 * @apiPermission      none
 *
 * @apiHeader          Accept application/json
 *
 * @apiParam           {String}     [username]   Email or phone both of them valid username is required when login_method=manual
 * @apiParam           {String}     [password]   password is required when login_method=manual
 * @apiParam           {String}     device_token  Device Id
 * @apiParam           {String}     login_by="android|ios"
 * @apiParam           {String}     login_method="manual|facebook|google"
 * @apiParam           {String}     [social_unique_id]     social_unique_id is required when login_method=facebook|google
 *
 *
 * @apiSuccessExample  {json}       Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *          "success": true,
 *          "success_message" : "Driver_Logged",
 *           "driver": {
 *                   "id": 1,
 *                   "firstname": "user",
 *                   "lastname": "test",
 *                   "email": "test@gmail.com",
 *                   "phone": "7200704057",
 *                   "login_by": "android",
 *                   "login_method": "manual",
 *                   "token" => "$2y$10$TMWF.x82d2.B8TUFsIqVk.LfYGpJ85EV2P8Ks3vjo6r3F8d047Sni"
 *                   }
 *   }
 *
 */

$router->post('/driver/login', [
    'as'   => 'driver/login',
    'uses'  => 'Controller@logindriver'
]);
