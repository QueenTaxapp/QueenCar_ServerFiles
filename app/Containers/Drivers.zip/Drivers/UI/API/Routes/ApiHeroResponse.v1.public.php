<?php

/**
 * @apiGroup           Hero
 * @apiName            HeroResponse
 * @api                {post} /hero/response Hero Response
 * @apiDescription     Hero Response
 * @apiVersion         1.0.0
 * @apiPermission      none
 *
 * @apiHeader          Accept application/json
 *
 * @apiParam           {Integer}    id   Hero ID
 * @apiParam           {String}     token   Token
 * @apiParam           {Integer}    request_id   Request ID
 * @apiParam           {Integer}    is_accepted="0|1"
 * @apiParam           {String}     [reason]    Hero Cancel Reason is required when is_accepted=0
 *
 *
 * @apiSuccessExample  {json}       Success-Response:Accepted
 *   HTTP/1.1 200 OK
 *   {
 *          "success": true,
 *                "request": {
 *                           "request_id": 2,
 *                           "lat": "67.76876000",
 *                           "long": "78.78560000",
 *                           "type": 1
 *                           },
 *                "user":  {
 *                         "firstname": "test",
 *                         "lastname": "user",
 *                         "email": "test@gmail.com",
 *                         "phone_number": "+919575485774"
 *                         }
 *
 *   }
 *
 * @apiSuccessExample  {json}       Success-Response:Canceled
 *   HTTP/1.1 200 OK
 *   {
 *          "success": true,
 *          "request_canceled": true,
 *
 *   }
 *
 */

$router->post('/hero/response', [
    'as'   => 'hero/response',
    'uses'  => 'Controller@ResponseHero',
]);
