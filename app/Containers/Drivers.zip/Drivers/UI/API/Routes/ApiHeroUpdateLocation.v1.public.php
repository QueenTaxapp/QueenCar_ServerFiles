<?php

/**
 * @apiGroup           Hero
 * @apiName            HeroUpdateLocation
 * @api                {post} /hero/updateLocation Hero Update Location
 * @apiDescription     Hero Update Location
 * @apiVersion         1.0.0
 * @apiPermission      none
 *
 * @apiHeader          Accept application/json
 *
 * @apiParam           {Integer}    id   Hero ID
 * @apiParam           {String}     token   Token
 * @apiParam           {String}     lat   Latitude
 * @apiParam           {String}     long   Longitude
 *
 *
 * @apiSuccessExample  {json}       Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *          "success": true,
 *           "location": {
 *                   "lat": "89.76767",
 *                   "long": "65.56464",
 *                   }
 *   }
 *
 */

$router->post('/hero/updateLocation', [
    'as'   => 'hero/updateLocation',
    'uses'  => 'Controller@updateLocationHero',
]);
