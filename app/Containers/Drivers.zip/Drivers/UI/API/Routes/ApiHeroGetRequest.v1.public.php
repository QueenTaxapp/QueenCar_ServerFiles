<?php

/**
 * @apiGroup           Hero
 * @apiName            HeroGetRequest
 * @api                {post} /hero/getRequest Hero Get Request
 * @apiDescription     Hero Get Request
 * @apiVersion         1.0.0
 * @apiPermission      none
 *
 * @apiHeader          Accept application/json
 *
 * @apiParam           {Integer}    id   Hero ID
 * @apiParam           {String}     token   Token
 *
 *
 * @apiSuccessExample  {json}       Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *          "success": true,
 *                "request": {
 *                           "request_id": 2,
 *                           "lat": "67.76876000",
 *                           "long": "78.78560000",
 *                           "type": 1
 *                           },
 *                "user":  {
 *                         "firstname": "test",
 *                         "lastname": "user",
 *                         "email": "test@gmail.com",
 *                         "phone_number": "+919575485774"
 *                         }
 *
 *   }
 *
 */

$router->post('/hero/getRequest', [
    'as'   => 'hero/getRequest',
    'uses'  => 'Controller@getRequestHero',
]);
