<?php

namespace App\Containers\Drivers\UI\API\Transformers;

use App\Ship\Parents\Transformers\Transformer;
use Illuminate\Http\Request;

/**
 * Class UserTransformer.
 *
 */
class HeroUpdateLocationTransformer extends Transformer
{
    /**
     * @param \App\Containers\Drivers\Models\HeroModel $hero
     *
     * @return array
     */
    public function transform($request)
    {

        $response = [
            'success' => true,
            'location' =>[

                'lat' =>  number_format($request->lat, 8),
                'long' => number_format($request->long, 8),
            ],
        ];


/*
        print_r($response);
        die("i");*/

        return $response;
    }


}
