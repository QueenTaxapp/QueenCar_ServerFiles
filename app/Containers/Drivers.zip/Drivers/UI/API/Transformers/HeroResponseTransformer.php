<?php

namespace App\Containers\Drivers\UI\API\Transformers;

use App\Ship\Parents\Transformers\Transformer;
use Illuminate\Http\Request;

/**
 * Class UserTransformer.
 *
 */
class HeroResponseTransformer extends Transformer
{
    /**
     * @param \App\Containers\Drivers\Models\HeroModel $hero
     *
     * @return array
     */
    public function transform($request)
    {

        $response = [
            'success' => true,
            'request_canceled' => true,
        ];

        return $response;
    }


}
