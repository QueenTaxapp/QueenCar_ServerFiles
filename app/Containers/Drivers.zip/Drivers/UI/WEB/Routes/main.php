<?php

/*  driver route */


$router->get('admin/driver/view', [
    'as'   => 'adminDriverView',
    'uses' => 'Controller@viewDriver',
    'module'=>"driver_module",
    'path'=>"adminDriverView",
    'icon'=>"account_circle",
    'order'=>"5",
    'privilege'=>TRUE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);
/**    * /driver/add - to view Hero add page  **/

$router->get('admin/driver/add', [
    'as'   => 'adminDriverAdd',
    'uses' => 'Controller@createDriver',
    'module'=>"driver_module",
    'privilege'=>TRUE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);

/**    * /saveuser- to save user  **/
$router->post('admin/driver/save', [
    'as'   => 'adminDriverSave',
    'uses' => 'Controller@saveDriver',
    'module'=>"driver_module",
    'privilege'=>FALSE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);

$router->get('admin/driver/edit/{id}', [
    'as'   => 'adminDriverEdit',
    'uses' => 'Controller@editDriver',
    'module'=>"driver_module",
    'privilege'=>TRUE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);

$router->post('admin/driver/update/{id}', [
    'as'   => 'adminDriverUpdate',
    'uses' => 'Controller@updateDriver',
    'module'=>"driver_module",
    'privilege'=>FALSE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);



$router->any('admin/driver/delete/{id}', [
    'as'   => 'adminDriverDelete',
    'uses' => 'Controller@deleteDriver',
    'module'=>"driver_module",
    'privilege'=>TRUE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);



$router->any('admin/driver/approve/{id}', [
    'as'   => 'adminDriverApprove',
    'uses' => 'Controller@approveDriver',
    'module'=>"driver_module",
    'privilege'=>TRUE,
    'middleware' => [
        'auth.web',
        'accessCheck.web',
    ]
]);
