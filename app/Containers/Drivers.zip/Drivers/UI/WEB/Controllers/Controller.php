<?php

namespace App\Containers\Drivers\UI\WEB\Controllers;

use App\Containers\Admin\Webtasks\EmailCheckTask;
use App\Containers\Admin\Webtasks\PhoneCheckTask;
use App\Containers\Common\GetConfigs;
use App\Containers\Company\Webtasks\ReportDownloadTask;
use App\Containers\Drivers\Models\DriverDocument;
use App\Containers\Drivers\Models\DriverModel;
use App\Containers\Drivers\Models\DriverTypeModel;
use App\Containers\Company\Models\CompanyModel;
use App\Containers\Drivers\UI\WEB\Requests\DriverAddRequest;
use App\Containers\Drivers\Webtasks\DriverDocumentSaveTask;
use App\Containers\Drivers\Webtasks\DriverDocumentUpdateTask;
use App\Containers\Drivers\Webtasks\DriverSaveTask;
use App\Containers\Drivers\Webtasks\DriverSearchTask;
use App\Containers\Drivers\Webtasks\DriverUpdateTask;
use App\Containers\Email\Models\EmailSettingsModel;
use App\Containers\Jobs\SendEmailJob;
use App\Containers\User\Models\Country;
use App\Containers\User\Tasks\ApiInsertUserImageTask;
use App\Containers\Drivers\Webtasks\DriverViewTask;
use App\Ship\Parents\Controllers\WebController;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;


/**
 * Class Controller
 *
 * @author  Mahmoud Zalt  <mahmoud@zalt.me>
 */
class Controller extends WebController
{

    public function viewDriver(Request $request)
    {
        $page = GetConfigs::getConfigs('paginate');

        $request->session()->put('filter_type',"");
        $request->session()->put('filter_value',"");
        $user="";

        if($request->has('filter_type') && $request->has('filter_type'))
        {
            $user = $this->call(DriverSearchTask::class, [$request]);

            if($request->submit && $request->submit == 'Download_Report')
            {
                // trans('localization::lang_view.s.no')

                $heading = array(
                    trans('localization::lang_view.firstname'),
                    trans('localization::lang_view.lastname'),
                    trans('localization::lang_view.email'),
                    trans('localization::lang_view.phone_number'),
                    trans('localization::lang_view.type'),
                    trans('localization::lang_view.status'));

                $key = array('firstname','lastname','email','phone_number','type','is_approve');

                $title = trans('localization::lang_view.driver_report');

                $value = $user;
                $this->call(ReportDownloadTask::class, [$heading,$value,$key,$title]);


            }
        }
        else
        {
            $user = $this->call(DriverViewTask::class,[$request]);
        }


        $title = trans('localization::title.driver');
        $page = "driver_module";

        return view('drivers::DriverView',['result'=>$user,'request'=>$request, 'title'=>$title, 'page'=> $page]);

    }




    public function createDriver(Request $request)
    {
        $title = trans('localization::title.driver');

        $page = "driver_module";

        $driver_types = DriverTypeModel::select('*')->get();

        $company = CompanyModel::select('*')->get();

        $country=Country::select('*')->get();

        return view('drivers::DriverAdd', ['request' => $request,'company' => $company, 'country_array' => $country, 'types' => $driver_types, 'title' => $title, 'page' => $page]);
    }


    public function saveDriver(DriverAddRequest $request)
    {
        $picture='';
        $token = $this->call(\App\Containers\Admin\Webtasks\SessionKeyTask::class);
        if($request->hasFile('profile_pic'))
        {
            $picture = $this->call(ApiInsertUserImageTask::class,[$request,'profile_pic']);
        }

        $driver = $this->call(DriverSaveTask::class,[$request,$token]);
        $driver->profile_pic=$picture?:"";
        $driver->save();

        $driver_document = $this->call(DriverDocumentSaveTask::class,[$request,$driver]);

//Driver
        //Email Table
        $emailTableDriver = EmailSettingsModel::where('title','=','welcome_email')->first();

        $driver_viewPage = $emailTableDriver->message;
        $driver_mailStatus  = $emailTableDriver->status;

        $driver_name=$driver->firstname.' '.$driver->lastname;
        $driver_email=$driver->email;
        $subject = "Welcome to ".GetConfigs::getConfigs('application_name');
        //Email Notification
        dispatch(new SendEmailJob($driver_viewPage,array('name'=>$driver_name,'date'=>date("d-m-y")),$driver_email,$subject,$driver_mailStatus));

        $response= array('success'=>"TRUE",'message'=>trans('localization::errors.driver_added_successfully'));
        //echo "<pre>";print_r($driver);die();
        $request->session()->flash('success',$response);

        if( $request->action == 'company')
        {
            return Redirect::to("/company/driver/view");
        }
        return Redirect::to("/admin/driver/view");
    }


    public function editDriver(Request $request)
    {
        $title = trans('localization::title.driver');
        $page = "driver_module";

        $driver = DriverModel::leftJoin('Driver_Details', 'Drivers.id', '=', 'Driver_Details.driver_id')->where('driver_id',$request->id)->first();

        $driver_documents = DriverDocument::where('driver_id',$request->id)->get();

        $driver_types = DriverTypeModel::select('*')->get();

        $company = CompanyModel::select('*')->get();

        $country=Country::select('*')->get();

        return view('drivers::DriverEdit', ['request' => $request,'driver' => $driver,'driver_documents' => $driver_documents, 'country_array' => $country, 'company' => $company, 'types' => $driver_types, 'title' => $title, 'page' => $page]);

    }


    public function updateDriver(DriverAddRequest $request)
    {
        //echo "<pre>";print_r($request->doc_id[2]);die();

        $id=$request->id;
        $email=$request->email;
        $phone=$request->phone_number;

        $email_count = $this->call(EmailCheckTask::class, ["App\Containers\Drivers\Models\DriverModel",$id,$email,'admin/driver/edit/']);

        $phone_count = $this->call(PhoneCheckTask::class, ["App\Containers\Drivers\Models\DriverModel",$id,$phone,"phone_number",'admin/driver/edit/']);

        if($email_count==0 && $phone_count==0)
        {
            $driver = $this->call(DriverUpdateTask::class,[$request]);
        }


        if($request->hasFile('profile_pic'))
        {
            $picture = $this->call(ApiInsertUserImageTask::class,[$request,'profile_pic']);
            $driver->profile_pic=$picture;
            $driver->save();
        }

        $driver_document = $this->call(DriverDocumentUpdateTask::class,[$request,$driver]);

        $response= array('success'=>"TRUE",'message'=>trans('localization::errors.driver_updated_successfully'));
       // echo "<pre>";print_r($driver);die();
        $request->session()->flash('success',$response);

        if( $request->action == 'company')
        {
            return Redirect::to("/company/driver/view");
        }


        return Redirect::to("/admin/driver/view");
    }




    public function deleteDriver(Request $request)
    {
        $data=DriverModel::where('id',$request->id)->update(['deleted_at' => date("Y-m-d h:i:s")]);

        $result= array('success'=>"TRUE",'message'=>trans('localization::errors.driver_deleted_successfully'));

        $request->session()->flash('success', $result);

        return Redirect::to("/admin/driver/view");
    }


    public function approveDriver(Request $request)
    {

        $driver =DriverModel::where('id',$request->id)->first();

        $old_state=$driver->is_approve;

        $response=array();
        if($old_state==0){
            $driver->is_approve = 1;
            $response = array('success'=>"TRUE",'message'=>trans('localization::errors.driver_approved_successfully'));
        }
        elseif($old_state==1)
        {
            $driver->is_approve = 0;
            $response = array('success'=>"TRUE",'message'=>trans('localization::errors.driver_declined_successfully'));
        }

        $driver->save();
        //echo "<pre>";print_r( $promo->state);die();

        $request->session()->flash('success', $response);
        return Redirect::to("/admin/driver/view");

    }


}

