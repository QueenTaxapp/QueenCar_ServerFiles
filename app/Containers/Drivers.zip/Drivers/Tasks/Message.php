<?php

namespace App\Containers\Admin\Tasks;
use Illuminate\Contracts\Validation\Validator;


/**
 * Class WebLoginTask.
 *
 * @author Mahmoud Zalt <mahmoud@zalt.me>
 */
class Message implements Validator
{

    public function failed()
    {
        // TODO: Implement failed() method.
    }

    public function fails()
    {
        // TODO: Implement fails() method.
    }

    public function after($callback)
    {
        // TODO: Implement after() method.
    }

    public function sometimes($attribute, $rules, callable $callback)
    {
        // TODO: Implement sometimes() method.
    }

public function getMessageBag()
{
    // TODO: Implement getMessageBag() method.
}

}