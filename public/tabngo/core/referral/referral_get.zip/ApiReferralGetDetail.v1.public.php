<?php

/**
 * @apiGroup           Users
 * @apiName            Get Referral Detail
 * @api                {post} /user/getreferral Get Referral Detail
 * @apiDescription     Get Referral Detail
 * @apiVersion         1.0.0
 * @apiPermission      none
 *
 * @apiHeader          Accept application/json
 *
 * @apiParam           {Integer}     id
 * @apiParam           {String}      token
 *
 * @apiSuccessExample  {json}    Success-Response:
 *
 * {
*       "success": true,
*       "success_message": "Get_Referral_code",
 *      "code": "123456",
 *       "earned": 1.3400000000000000799360577730112709105014801025390625,
 *       "spent": 0,
 *       "balance": 0
*   }
 *
 */

    $router->post('/user/getreferral', [
        'as'   => 'referral@getreferral',
        'uses' => 'Controller@run',
        'middleware' => [
            'userTokenCheck.api',
        ]
    ]);



